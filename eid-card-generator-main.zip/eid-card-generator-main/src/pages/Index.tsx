
import React, { useState } from 'react';
import NameForm from '@/components/NameForm';
import EidCard from '@/components/EidCard';
import { Moon, Star } from 'lucide-react';

const Index: React.FC = () => {
  const [userName, setUserName] = useState<string>('');
  
  const handleNameSubmit = (name: string) => {
    setUserName(name);
  };
  
  const handleReset = () => {
    setUserName('');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden bg-gradient-to-br from-white to-eid-cream">
      {/* Decorative background elements */}
      <div className="absolute top-10 left-10 opacity-70">
        <Moon className="text-eid-green w-10 h-10 animate-float" strokeWidth={1} />
      </div>
      <div className="absolute bottom-16 right-10 opacity-70">
        <Moon className="text-eid-green w-8 h-8 animate-float" strokeWidth={1} />
      </div>
      <div className="absolute top-1/4 right-16 opacity-70">
        <Star className="text-eid-gold w-6 h-6 animate-float" strokeWidth={1} />
      </div>
      <div className="absolute bottom-1/3 left-16 opacity-70">
        <Star className="text-eid-gold w-5 h-5 animate-float" strokeWidth={1} />
      </div>
      
      {/* Header */}
      <div className="text-center mb-8 animate-fade-in">
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold font-amiri">
          <span className="text-eid-green">Kartu Ucapan</span>
          <span className="block text-eid-teal">Idul Fitri 1446H</span>
        </h1>
      </div>
      
      {/* Main content */}
      <div className="w-full max-w-4xl relative z-10">
        {!userName ? (
          <NameForm onSubmit={handleNameSubmit} />
        ) : (
          <EidCard name={userName} onReset={handleReset} />
        )}
      </div>
      
      {/* Footer */}
      <footer className="w-full mt-auto pt-8 pb-4 text-center text-sm text-gray-500">
        <p>Eid al-Fitr 1446 Hijriah / 2025 Masehi</p>
      </footer>
    </div>
  );
};

export default Index;
