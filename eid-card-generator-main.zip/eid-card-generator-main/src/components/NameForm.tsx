
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";

interface NameFormProps {
  onSubmit: (name: string) => void;
}

const NameForm: React.FC<NameFormProps> = ({ onSubmit }) => {
  const [name, setName] = useState('');
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (name.trim() === '') {
      toast({
        title: "Nama diperlukan",
        description: "Silakan masukkan nama Anda untuk melanjutkan",
        variant: "destructive",
      });
      return;
    }
    
    onSubmit(name);
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-md space-y-4 animate-fade-in">
      <div className="space-y-2 text-center">
        <h2 className="text-xl font-semibold text-eid-green">Masukkan Nama Anda</h2>
        <p className="text-sm text-muted-foreground">
          Buat ucapan Selamat Hari Raya Idul Fitri 1446H dari nama Anda
        </p>
      </div>
      
      <div className="flex flex-col space-y-4">
        <Input
          type="text"
          placeholder="Nama Anda"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="border-eid-green/30 focus:border-eid-green focus:ring-eid-green"
          autoComplete="name"
        />
        
        <Button 
          type="submit" 
          className="bg-eid-green hover:bg-eid-green/90 text-white transition-all"
        >
          Buat Kartu Ucapan
        </Button>
      </div>
    </form>
  );
};

export default NameForm;
