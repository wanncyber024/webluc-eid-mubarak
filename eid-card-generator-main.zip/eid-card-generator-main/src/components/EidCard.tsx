
import React from 'react';
import { Button } from "@/components/ui/button";
import { Moon, Star } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

interface EidCardProps {
  name: string;
  onReset: () => void;
}

const EidCard: React.FC<EidCardProps> = ({ name, onReset }) => {
  const { toast } = useToast();
  
  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Selamat Hari Raya Idul Fitri 1446H',
        text: `Selamat Hari Raya Idul Fitri 1446H! Mohon maaf lahir dan batin. Dari: ${name}`,
      }).catch(() => {
        toast({
          title: "Info",
          description: "Berbagi tidak tersedia atau dibatalkan",
        });
      });
    } else {
      // Fallback for browsers that don't support Web Share API
      toast({
        title: "Info",
        description: "Berbagi tidak didukung di browser Anda",
      });
    }
  };

  return (
    <div className="w-full max-w-xl mx-auto p-6 animate-fade-in">
      <div className="relative overflow-hidden rounded-2xl shadow-lg border border-eid-gold/30">
        {/* Card Background */}
        <div className="eid-card-pattern p-8 md:p-10">
          {/* Decorative elements */}
          <div className="absolute top-4 right-4">
            <Moon className="text-eid-gold w-8 h-8 animate-float" fill="#E6B800" stroke="none" />
          </div>
          <div className="absolute bottom-12 left-6">
            <Star className="text-eid-gold w-6 h-6 animate-float" fill="#E6B800" stroke="none" />
          </div>
          <div className="absolute top-16 left-6">
            <Star className="text-eid-gold w-4 h-4 animate-float" fill="#E6B800" stroke="none" />
          </div>
          <div className="absolute bottom-24 right-8">
            <Star className="text-eid-gold w-5 h-5 animate-float" fill="#E6B800" stroke="none" />
          </div>
          
          {/* Card Content */}
          <div className="relative z-10 text-center space-y-6">
            {/* Eid greeting in Arabic and Indonesian */}
            <div className="space-y-4">
              <h2 className="font-amiri text-3xl md:text-4xl text-eid-green font-bold">عيد الفطر مبارك</h2>
              <h2 className="text-2xl md:text-3xl font-bold text-eid-teal">Selamat Hari Raya Idul Fitri 1446H</h2>
            </div>
            
            {/* Personalized message */}
            <div className="py-6 px-4 md:py-8 space-y-4">
              <p className="text-eid-green text-lg md:text-xl">
                Taqabbalallahu minna wa minkum, shiyamana wa shiyamakum
              </p>
              <p className="text-gray-700">
                Semoga Allah menerima amal ibadah kita dan puasa kita
              </p>
              <p className="text-lg md:text-xl font-medium mt-4">
                Mohon maaf lahir dan batin
              </p>
            </div>
            
            {/* From name */}
            <div className="pt-4 border-t border-eid-gold/30">
              <p className="font-medium text-eid-green">Dari:</p>
              <p className="text-xl md:text-2xl font-bold text-eid-teal">{name}</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row justify-center gap-4 mt-6">
        <Button 
          onClick={onReset}
          variant="outline" 
          className="border-eid-green text-eid-green hover:bg-eid-green/10"
        >
          Buat Kartu Baru
        </Button>
        <Button 
          onClick={handleShare}
          className="bg-eid-teal hover:bg-eid-teal/90 text-white"
        >
          Bagikan Ucapan
        </Button>
      </div>
    </div>
  );
};

export default EidCard;
